﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListHosting = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.THargaHosting = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ListDomain = New System.Windows.Forms.ComboBox()
        Me.THargaDomain = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BtnHitung = New System.Windows.Forms.Button()
        Me.TjumlahBayar = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TMasaAktif = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ListHosting
        '
        Me.ListHosting.FormattingEnabled = True
        Me.ListHosting.Items.AddRange(New Object() {"ENTRY", "SMALL", "MEDIUM", "LARGE"})
        Me.ListHosting.Location = New System.Drawing.Point(28, 163)
        Me.ListHosting.Name = "ListHosting"
        Me.ListHosting.Size = New System.Drawing.Size(289, 28)
        Me.ListHosting.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 142)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Paket Hosting"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(378, 142)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Harga Hosting"
        '
        'THargaHosting
        '
        Me.THargaHosting.Location = New System.Drawing.Point(371, 163)
        Me.THargaHosting.Name = "THargaHosting"
        Me.THargaHosting.Size = New System.Drawing.Size(171, 26)
        Me.THargaHosting.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(151, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(391, 29)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Mulai dengan Hosting Mulai Dari"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Cooper Std Black", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(222, 68)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(212, 24)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "NYPS WEB MEDIA"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(194, 92)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(240, 32)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "........................."
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(37, 212)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(164, 24)
        Me.CheckBox1.TabIndex = 7
        Me.CheckBox1.Text = "Termasuk Domain"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(33, 248)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(120, 20)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Extensi Domain"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(378, 244)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(112, 20)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Harga Domain"
        '
        'ListDomain
        '
        Me.ListDomain.FormattingEnabled = True
        Me.ListDomain.Items.AddRange(New Object() {".COM", ".ID", ".ORG", ".SCH", ".AC.ID"})
        Me.ListDomain.Location = New System.Drawing.Point(28, 274)
        Me.ListDomain.Name = "ListDomain"
        Me.ListDomain.Size = New System.Drawing.Size(288, 28)
        Me.ListDomain.TabIndex = 10
        '
        'THargaDomain
        '
        Me.THargaDomain.Location = New System.Drawing.Point(371, 274)
        Me.THargaDomain.Name = "THargaDomain"
        Me.THargaDomain.Size = New System.Drawing.Size(163, 26)
        Me.THargaDomain.TabIndex = 11
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Black
        Me.GroupBox1.Controls.Add(Me.BtnHitung)
        Me.GroupBox1.Controls.Add(Me.TjumlahBayar)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.TMasaAktif)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(38, 325)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(546, 275)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "<< Perhitungan Tagihan >>"
        '
        'BtnHitung
        '
        Me.BtnHitung.ForeColor = System.Drawing.Color.Black
        Me.BtnHitung.Location = New System.Drawing.Point(339, 73)
        Me.BtnHitung.Name = "BtnHitung"
        Me.BtnHitung.Size = New System.Drawing.Size(164, 45)
        Me.BtnHitung.TabIndex = 4
        Me.BtnHitung.Text = "HITUNG"
        Me.BtnHitung.UseVisualStyleBackColor = True
        '
        'TjumlahBayar
        '
        Me.TjumlahBayar.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TjumlahBayar.Location = New System.Drawing.Point(32, 155)
        Me.TjumlahBayar.Name = "TjumlahBayar"
        Me.TjumlahBayar.Size = New System.Drawing.Size(382, 57)
        Me.TjumlahBayar.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(37, 118)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(105, 20)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Jumlah Bayar"
        '
        'TMasaAktif
        '
        Me.TMasaAktif.Location = New System.Drawing.Point(28, 81)
        Me.TMasaAktif.Name = "TMasaAktif"
        Me.TMasaAktif.Size = New System.Drawing.Size(249, 26)
        Me.TMasaAktif.TabIndex = 1
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(35, 57)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(139, 20)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Masa Aktif (Bulan)"
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Location = New System.Drawing.Point(211, 608)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(199, 36)
        Me.BtnKeluar.TabIndex = 13
        Me.BtnKeluar.Text = "KELUAR"
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Yellow
        Me.ClientSize = New System.Drawing.Size(766, 656)
        Me.Controls.Add(Me.BtnKeluar)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.THargaDomain)
        Me.Controls.Add(Me.ListDomain)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.THargaHosting)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ListHosting)
        Me.Name = "Form2"
        Me.Text = "Order Paket Hosting"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ListHosting As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents THargaHosting As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents ListDomain As ComboBox
    Friend WithEvents THargaDomain As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents BtnHitung As Button
    Friend WithEvents TjumlahBayar As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TMasaAktif As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents BtnKeluar As Button
End Class
