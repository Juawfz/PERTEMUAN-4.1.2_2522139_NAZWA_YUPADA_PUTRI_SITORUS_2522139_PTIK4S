﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextNamaBarang = New System.Windows.Forms.TextBox()
        Me.TextJumlah = New System.Windows.Forms.TextBox()
        Me.TextHargaSatuan = New System.Windows.Forms.TextBox()
        Me.BtnReset = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextTotalHarga = New System.Windows.Forms.TextBox()
        Me.TextDiskon = New System.Windows.Forms.TextBox()
        Me.TextTotalBayar = New System.Windows.Forms.TextBox()
        Me.TextBonus = New System.Windows.Forms.TextBox()
        Me.BtnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'TextNamaBarang
        '
        Me.TextNamaBarang.Location = New System.Drawing.Point(184, 65)
        Me.TextNamaBarang.Name = "TextNamaBarang"
        Me.TextNamaBarang.Size = New System.Drawing.Size(335, 26)
        Me.TextNamaBarang.TabIndex = 0
        '
        'TextJumlah
        '
        Me.TextJumlah.Location = New System.Drawing.Point(184, 160)
        Me.TextJumlah.Name = "TextJumlah"
        Me.TextJumlah.Size = New System.Drawing.Size(200, 26)
        Me.TextJumlah.TabIndex = 1
        '
        'TextHargaSatuan
        '
        Me.TextHargaSatuan.Location = New System.Drawing.Point(184, 115)
        Me.TextHargaSatuan.Name = "TextHargaSatuan"
        Me.TextHargaSatuan.Size = New System.Drawing.Size(192, 26)
        Me.TextHargaSatuan.TabIndex = 2
        '
        'BtnReset
        '
        Me.BtnReset.Location = New System.Drawing.Point(400, 153)
        Me.BtnReset.Name = "BtnReset"
        Me.BtnReset.Size = New System.Drawing.Size(128, 33)
        Me.BtnReset.TabIndex = 3
        Me.BtnReset.Text = "Resert"
        Me.BtnReset.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(107, 20)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Nama Barang"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(199, 202)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(255, 20)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Enter untuk menghitung Belanjaan"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 166)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 20)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Jumlah Item"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(15, 121)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 20)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Harga satuan"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(25, 341)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(89, 20)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Total Bayar"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 292)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(58, 20)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Diskon"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(15, 242)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(92, 20)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Total Harga"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(33, 390)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 20)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Bonus"
        '
        'TextTotalHarga
        '
        Me.TextTotalHarga.Location = New System.Drawing.Point(184, 239)
        Me.TextTotalHarga.Name = "TextTotalHarga"
        Me.TextTotalHarga.Size = New System.Drawing.Size(200, 26)
        Me.TextTotalHarga.TabIndex = 12
        '
        'TextDiskon
        '
        Me.TextDiskon.Location = New System.Drawing.Point(184, 292)
        Me.TextDiskon.Name = "TextDiskon"
        Me.TextDiskon.Size = New System.Drawing.Size(200, 26)
        Me.TextDiskon.TabIndex = 13
        '
        'TextTotalBayar
        '
        Me.TextTotalBayar.Location = New System.Drawing.Point(184, 335)
        Me.TextTotalBayar.Name = "TextTotalBayar"
        Me.TextTotalBayar.Size = New System.Drawing.Size(200, 26)
        Me.TextTotalBayar.TabIndex = 14
        '
        'TextBonus
        '
        Me.TextBonus.Location = New System.Drawing.Point(184, 390)
        Me.TextBonus.Name = "TextBonus"
        Me.TextBonus.Size = New System.Drawing.Size(200, 26)
        Me.TextBonus.TabIndex = 15
        '
        'BtnClose
        '
        Me.BtnClose.ForeColor = System.Drawing.Color.Black
        Me.BtnClose.Location = New System.Drawing.Point(218, 443)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(127, 33)
        Me.BtnClose.TabIndex = 16
        Me.BtnClose.Text = "TUTUP"
        Me.BtnClose.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Aqua
        Me.ClientSize = New System.Drawing.Size(870, 489)
        Me.Controls.Add(Me.BtnClose)
        Me.Controls.Add(Me.TextBonus)
        Me.Controls.Add(Me.TextTotalBayar)
        Me.Controls.Add(Me.TextDiskon)
        Me.Controls.Add(Me.TextTotalHarga)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnReset)
        Me.Controls.Add(Me.TextHargaSatuan)
        Me.Controls.Add(Me.TextJumlah)
        Me.Controls.Add(Me.TextNamaBarang)
        Me.Name = "Form1"
        Me.Text = "PROGRAM BELANJA"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextNamaBarang As TextBox
    Friend WithEvents TextJumlah As TextBox
    Friend WithEvents TextHargaSatuan As TextBox
    Friend WithEvents BtnReset As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents TextTotalHarga As TextBox
    Friend WithEvents TextDiskon As TextBox
    Friend WithEvents TextTotalBayar As TextBox
    Friend WithEvents TextBonus As TextBox
    Friend WithEvents BtnClose As Button
End Class
